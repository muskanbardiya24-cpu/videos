# Diabetes Risk Demonstration
# Ubuntu: python3 diabetes_risk.py
# Dependencies: Python 3 standard library only (no internet needed).

# First-order Sugeno ANFIS-style demonstration with 2 Gaussian membership
# functions (LOW and HIGH) per input; learn linear rule consequents by SGD.
# The dataset is generated synthetically for demonstration purposes only.
from itertools import product
from math import exp

names = ['age', 'BMI', 'blood pressure', 'glucose']
ranges = [(20, 70), (18, 38), (80, 150), (70, 180)]
example = [45, 30, 115, 130]
scale = 100

def target(x):
    return max(0,min(100, 0.6*(x[0]-20)+1.7*(x[1]-18)+0.18*(x[2]-80)+0.06*(x[3]-70)))

def gaussian(x, mean, sigma):
    return exp(-0.5*((x-mean)/sigma)**2)

def normalized(x):
    return [(v-lo)/(hi-lo) for v,(lo,hi) in zip(x,ranges)]

def rule_weights(x):
    # LOW/HIGH Gaussian MF of each input; 2**N rules.
    degrees=[]
    for v,(lo,hi) in zip(x,ranges):
        span=hi-lo
        degrees.append((gaussian(v,lo+0.25*span,span/3),
                        gaussian(v,lo+0.75*span,span/3)))
    fires=[]
    for choices in product([0,1],repeat=len(x)):
        weight=1.0
        for j,choice in enumerate(choices):
            weight*=degrees[j][choice]
        fires.append(weight)
    total=sum(fires)
    return [f/total for f in fires]

n=len(ranges)
num_rules=2**n
weights=[[0.0]*(n+1) for _ in range(num_rules)]

# Synthetic supervised training examples (three values for each feature).
levels=[[lo, (lo+hi)/2, hi] for lo,hi in ranges]
training=[]
for row in product(*levels):
    training.append((row,target(row)/scale))

for epoch in range(55):
    for raw,y in training:
        x=[1.0]+normalized(raw)
        firing=rule_weights(raw)
        estimated=sum(f*sum(a*b for a,b in zip(w,x))
                      for f,w in zip(firing,weights))
        error=y-estimated
        for j in range(num_rules):
            for k in range(n+1):
                weights[j][k]+=0.18*error*firing[j]*x[k]

print('Case:', 'Diabetes Risk Demonstration')
print('Membership functions/input: 2 (Gaussian)')
print('Number of fuzzy rules:', num_rules)
print('Enter inputs or press Enter to use example values:')
values=[]
for name,(lo,hi),default in zip(names,ranges,example):
    v=float(input(f'{name} ({lo}..{hi}) [{default}]: ') or default)
    if not lo <= v <= hi:
        raise ValueError(f'{name} must be between {lo} and {hi}')
    values.append(v)
x=[1.0]+normalized(values)
firing=rule_weights(values)
result=sum(f*sum(a*b for a,b in zip(w,x))
           for f,w in zip(firing,weights))*scale
print('synthetic risk score (0-100):',round(result,2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: Press Enter for the displayed example values.
# OUTPUT: Case: Diabetes Risk Demonstration
# OUTPUT: Membership functions/input: 2 (Gaussian)
# OUTPUT: Number of fuzzy rules: 16
# OUTPUT: Enter inputs or press Enter to use example values:
# OUTPUT: age (20..70) [45]: BMI (18..38) [30]: blood pressure (80..150) [115]: glucose (70..180) [130]: synthetic risk score (0-100): 44.67
