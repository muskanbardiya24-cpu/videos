# 8 Puzzle A Star with Manhattan Distance
# Ubuntu: python3 eight_puzzle.py
# Dependencies: Python 3 standard library only (no internet needed).

import heapq

start = (1, 2, 3, 4, 0, 6, 7, 5, 8)
goal = (1, 2, 3, 4, 5, 6, 7, 8, 0)

def h(state):
    return sum(abs(i//3 - goal.index(v)//3) + abs(i%3 - goal.index(v)%3)
               for i, v in enumerate(state) if v)

def neighbors(state):
    z = state.index(0)
    r, c = divmod(z, 3)
    for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
        nr, nc = r+dr, c+dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            k = nr*3+nc
            new = list(state)
            new[z],new[k] = new[k],new[z]
            yield tuple(new)

pq = [(h(start), 0, start)]
g_score, parent = {start:0}, {start:None}
while pq:
    _,g,s = heapq.heappop(pq)
    if s == goal:
        break
    if g != g_score[s]:
        continue
    for t in neighbors(s):
        if g+1 < g_score.get(t,float('inf')):
            g_score[t] = g+1
            parent[t] = s
            heapq.heappush(pq,(g+1+h(t),g+1,t))

if goal not in parent:
    print('No solution')
else:
    path, s = [], goal
    while s is not None:
        path.append(s)
        s = parent[s]
    print('A* moves:', len(path)-1)
    for state in path[::-1]:
        for i in (0,3,6):
            print(*state[i:i+3])
        print()

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: A* moves: 2
# OUTPUT: 1 2 3
# OUTPUT: 4 0 6
# OUTPUT: 7 5 8
# OUTPUT: 
# OUTPUT: 1 2 3
# OUTPUT: 4 5 6
# OUTPUT: 7 0 8
# OUTPUT: 
# OUTPUT: 1 2 3
# OUTPUT: 4 5 6
# OUTPUT: 7 8 0
