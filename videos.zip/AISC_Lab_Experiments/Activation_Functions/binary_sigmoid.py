# Binary Step and Sigmoid Activation Functions
# Ubuntu: python3 binary_sigmoid.py
# Dependencies: Python 3 standard library only (no internet needed).

import math

def binary_step(x):
    return 1 if x >= 0 else 0

def sigmoid(x):
    return 1 / (1 + math.exp(-x))

print('Input  Binary  Sigmoid')
for x in [-2, -1, 0, 1, 2]:
    print(f'{x:>5} {binary_step(x):>7}  {sigmoid(x):.4f}')

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Input  Binary  Sigmoid
# OUTPUT:    -2       0  0.1192
# OUTPUT:    -1       0  0.2689
# OUTPUT:     0       1  0.5000
# OUTPUT:     1       1  0.7311
# OUTPUT:     2       1  0.8808
