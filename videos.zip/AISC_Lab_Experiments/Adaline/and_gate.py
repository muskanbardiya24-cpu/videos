# ADALINE AND Gate
# Ubuntu: python3 and_gate.py
# Dependencies: Python 3 standard library only (no internet needed).

# ADALINE for AND Gate
# AND gate dataset
X = [[0,0],
     [0,1],
     [1,0],
     [1,1]]
T = [0,0,0,1]

# Initial weights
w1 = 0.0
w2 = 0.0
bias = 0.0
learning_rate = 0.1

print("Epoch\tMean Squared Error")

# Training
for epoch in range(1,21):
    total_error = 0
    for i in range(len(X)):
        x1 = X[i][0]
        x2 = X[i][1]

        # Linear output
        yin = x1*w1 + x2*w2 + bias

        # Error
        error = T[i] - yin

        # Delta rule weight update
        w1 = w1 + learning_rate * error * x1
        w2 = w2 + learning_rate * error * x2
        bias = bias + learning_rate * error
        total_error += error**2

    # Mean Squared Error
    mse = total_error / len(X)
    print(epoch, "\t", round(mse,4))

# Final parameters
print("\nFinal Weights:")
print("w1 =", round(w1,4))
print("w2 =", round(w2,4))
print("Bias =", round(bias,4))

# Testing
print("\nPredictions:")
for i in range(len(X)):
    x1 = X[i][0]
    x2 = X[i][1]
    yin = x1*w1 + x2*w2 + bias

    # Convert continuous output into binary
    output = 1 if yin >= 0.5 else 0
    print(X[i],"Target:", T[i], "Output:", output)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Epoch	Mean Squared Error
# OUTPUT: 1 	 0.25
# OUTPUT: 2 	 0.1718
# OUTPUT: 3 	 0.1508
# OUTPUT: 4 	 0.1411
# OUTPUT: 5 	 0.1336
# OUTPUT: 6 	 0.1268
# OUTPUT: 7 	 0.1206
# OUTPUT: 8 	 0.115
# OUTPUT: 9 	 0.1101
# OUTPUT: 10 	 0.1058
# OUTPUT: 11 	 0.102
# OUTPUT: 12 	 0.0987
# OUTPUT: 13 	 0.0958
# OUTPUT: 14 	 0.0933
# OUTPUT: 15 	 0.0912
# OUTPUT: ... extra lines omitted from sample
