# Associative Memory bam
# Ubuntu: python3 bam.py
# Dependencies: Python 3 standard library only (no internet needed).

X = [1, -1, 1]
Y = [1, 1]

# Create weight matrix
W = []

for i in range(len(X)):
    row = []

    for j in range(len(Y)):
        row.append(X[i] * Y[j])

    W.append(row)

# Forward recall: X to Y
Y_result = []

for j in range(len(Y)):
    net = 0

    for i in range(len(X)):
        net += X[i] * W[i][j]

    Y_result.append(1 if net >= 0 else -1)

# Backward recall: Y to X
X_result = []

for i in range(len(X)):
    net = 0

    for j in range(len(Y)):
        net += W[i][j] * Y_result[j]

    X_result.append(1 if net >= 0 else -1)

print("Input X:", X)
print("Target Y:", Y)

print("Weight Matrix:")
for row in W:
    print(row)

print("Forward Recall Y:", Y_result)
print("Backward Recall X:", X_result)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Input X: [1, -1, 1]
# OUTPUT: Target Y: [1, 1]
# OUTPUT: Weight Matrix:
# OUTPUT: [1, 1]
# OUTPUT: [-1, -1]
# OUTPUT: [1, 1]
# OUTPUT: Forward Recall Y: [1, 1]
# OUTPUT: Backward Recall X: [1, -1, 1]
