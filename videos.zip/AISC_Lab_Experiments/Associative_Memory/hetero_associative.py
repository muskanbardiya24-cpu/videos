# Associative Memory hetero
# Ubuntu: python3 hetero_associative.py
# Dependencies: Python 3 standard library only (no internet needed).

X = [1, -1, 1]
Y = [1, 1]

# Create weight matrix
W = []

for i in range(len(X)):
    row = []

    for j in range(len(Y)):
        row.append(X[i] * Y[j])

    W.append(row)

# Recall output from input
output = []

for j in range(len(Y)):
    net = 0

    for i in range(len(X)):
        net += X[i] * W[i][j]

    output.append(1 if net >= 0 else -1)

print("Input Pattern:", X)
print("Target Pattern:", Y)

print("Weight Matrix:")
for row in W:
    print(row)

print("Recalled Output:", output)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Input Pattern: [1, -1, 1]
# OUTPUT: Target Pattern: [1, 1]
# OUTPUT: Weight Matrix:
# OUTPUT: [1, 1]
# OUTPUT: [-1, -1]
# OUTPUT: [1, 1]
# OUTPUT: Recalled Output: [1, 1]
