# DFS Maze S to E
# Ubuntu: python3 dfs_matrix.py
# Dependencies: Python 3 standard library only (no internet needed).

# 0 = open cell; 1 = wall. Find a path from S to E using DFS.
grid = [
    ['S', '0', '0', '1'],
    ['1', '0', '0', '1'],
    ['1', '1', '0', 'E']
]
start = (0, 0)
end = (2, 3)
visited = set()
path = []

def dfs(r, c):
    if not (0 <= r < len(grid) and 0 <= c < len(grid[0])):
        return False
    if grid[r][c] == '1' or (r,c) in visited:
        return False
    visited.add((r,c))
    path.append((r,c))
    if (r,c) == end:
        return True
    for dr, dc in [(0,1),(1,0),(0,-1),(-1,0)]:
        if dfs(r+dr, c+dc):
            return True
    path.pop()
    return False

print('Matrix:')
for row in grid:
    print(' '.join(row))
if dfs(*start):
    print('DFS Path:', ' -> '.join(map(str, path)))
else:
    print('No path found')

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Matrix:
# OUTPUT: S 0 0 1
# OUTPUT: 1 0 0 1
# OUTPUT: 1 1 0 E
# OUTPUT: DFS Path: (0, 0) -> (0, 1) -> (0, 2) -> (1, 2) -> (2, 2) -> (2, 3)
