# Six Node Graph Traversal and Path A to F
# Ubuntu: python3 six_node_graph.py
# Dependencies: Python 3 standard library only (no internet needed).

from collections import deque

nodes = 'ABCDEF'
graph = {node: [] for node in nodes}
n = int(input('Number of roads: '))
for _ in range(n):
    a, b = input('Road (e.g. A B): ').upper().split()
    if a not in graph or b not in graph:
        raise ValueError('Use only nodes A through F.')
    graph[a].append(b)
    graph[b].append(a)
for node in graph:
    graph[node] = sorted(set(graph[node]))

# BFS traversal of all six nodes (including disconnected components).
visited, order = set(), []
for start in nodes:
    if start in visited:
        continue
    queue = deque([start])
    visited.add(start)
    while queue:
        current = queue.popleft()
        order.append(current)
        for neighbor in graph[current]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
print('BFS traversal:', ' -> '.join(order))

# BFS gives shortest path (fewest roads) in an unweighted graph.
queue = deque(['A'])
parent = {'A': None}
while queue:
    current = queue.popleft()
    if current == 'F':
        break
    for neighbor in graph[current]:
        if neighbor not in parent:
            parent[neighbor] = current
            queue.append(neighbor)
if 'F' not in parent:
    print('A to F: No path')
else:
    path, node = [], 'F'
    while node is not None:
        path.append(node)
        node = parent[node]
    print('A to F:', ' -> '.join(path[::-1]))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: 6
# INPUT: A B
# INPUT: A C
# INPUT: B D
# INPUT: C E
# INPUT: D F
# INPUT: E F
# OUTPUT: Number of roads: Road (e.g. A B): Road (e.g. A B): Road (e.g. A B): Road (e.g. A B): Road (e.g. A B): Road (e.g. A B): BFS traversal: A -> B -> C -> D -> E -> F
# OUTPUT: A to F: A -> B -> D -> F
