# Backpropagation Numerical Worked Example
# Ubuntu: python3 numerical.py
# Dependencies: Python 3 standard library only (no internet needed).

# Backpropagation Neural Network
# Architecture: 2 Input - 2 Hidden - 1 Output
import math

# Sigmoid activation function
def sigmoid(x):
    return 1 / (1 + math.exp(-x))

# Input and target
x1 = 0.5
x2 = 0.8
target = 1

# Initial weights
# Input to Hidden layer
w11 = 0.2
w21 = 0.3

w12 = 0.4
w22 = 0.5

# Hidden to Output layer
v1 = 0.6
v2 = 0.7

# Biases
b1 = 0.1
b2 = 0.1
bo = 0.1

learning_rate = 0.5

# Training
for epoch in range(1, 6):

    # ---------- Forward Propagation ----------
    h1 = sigmoid(x1*w11 + x2*w21 + b1)
    h2 = sigmoid(x1*w12 + x2*w22 + b2)

    output = sigmoid(h1*v1 + h2*v2 + bo)

    # Error
    error = target - output

    # ---------- Back Propagation ----------
    # Output layer delta
    delta_output = error * output * (1-output)

    # Hidden layer delta
    delta_h1 = h1*(1-h1)*delta_output*v1
    delta_h2 = h2*(1-h2)*delta_output*v2

    # ---------- Weight Updates ---------
    # Hidden to Output
    v1 = v1 + learning_rate*delta_output*h1
    v2 = v2 + learning_rate*delta_output*h2
    bo = bo + learning_rate*delta_output

    # Input to Hidden
    w11 = w11 + learning_rate*delta_h1*x1
    w21 = w21 + learning_rate*delta_h1*x2
    b1 = b1 + learning_rate*delta_h1

    w12 = w12 + learning_rate*delta_h2*x1
    w22 = w22 + learning_rate*delta_h2*x2
    b2 = b2 + learning_rate*delta_h2

    print("Epoch:", epoch,
          "Output:", round(output,4),
          "Error:", round(error,4))

print("\nFinal Output:", round(output,4))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Epoch: 1 Output: 0.7176 Error: 0.2824
# OUTPUT: Epoch: 2 Output: 0.7285 Error: 0.2715
# OUTPUT: Epoch: 3 Output: 0.7386 Error: 0.2614
# OUTPUT: Epoch: 4 Output: 0.7478 Error: 0.2522
# OUTPUT: Epoch: 5 Output: 0.7564 Error: 0.2436
# OUTPUT: 
# OUTPUT: Final Output: 0.7564
