# Coffee Brewing Controller - scikit-fuzzy
# Ubuntu: python3 coffee_brewing.py
# Setup BEFORE the offline lab exam (requires internet):
# python3 -m pip install numpy scikit-fuzzy
# Offline alternative: use the corresponding file in Fuzzy/Without_SkFuzzy.

import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

# Mamdani fuzzy controller using scikit-fuzzy.
lo1,hi1 = 70,100
lo2,hi2 = 0,10
out_lo,out_hi = 60,300
a = ctrl.Antecedent(np.linspace(lo1,hi1,101),'input_a')
b = ctrl.Antecedent(np.linspace(lo2,hi2,101),'input_b')
c = ctrl.Consequent(np.linspace(out_lo,out_hi,201),'output')
for var,lo,hi in [(a,lo1,hi1),(b,lo2,hi2),(c,out_lo,out_hi)]:
    mid = (lo+hi)/2
    var['low'] = fuzz.trimf(var.universe,[lo,lo,mid])
    var['mid'] = fuzz.trimf(var.universe,[lo,mid,hi])
    var['high'] = fuzz.trimf(var.universe,[mid,hi,hi])

def output_level(i,j):
    return max(0,min(2,1+j-i)) # stronger -> longer, hotter -> shorter

labels = ['low','mid','high']
rules = [ctrl.Rule(a[labels[i]] & b[labels[j]],
                   c[labels[output_level(i,j)]])
         for i in range(3) for j in range(3)]
system = ctrl.ControlSystem(rules)
sim = ctrl.ControlSystemSimulation(system)
x = float(input('water temperature (C): ') or '90')
y = float(input('coffee strength (0-10): ') or '8')
if not (lo1 <= x <= hi1 and lo2 <= y <= hi2):
    raise ValueError('Inputs must be inside the indicated ranges.')
sim.input['input_a'] = x
sim.input['input_b'] = y
sim.compute()
print('brew time (seconds):',round(sim.output['output'],2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: 90
# INPUT: 8
# OUTPUT: Not tested here (scikit-fuzzy is not installed).
# OUTPUT: Approximate result using pure-Python version:
# OUTPUT: water temperature (C): coffee strength (0-10): brew time (seconds): 193.08
