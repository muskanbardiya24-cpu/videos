# Drone Roll and Pitch Stabilization - scikit-fuzzy
# Ubuntu: python3 drone_stabilization.py
# Install before offline lab: python3 -m pip install numpy scikit-fuzzy
# On Ubuntu, create and activate a virtual environment first if pip is restricted.

import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

# Two independent controllers: roll and pitch, as in supplied lab source.
# Signed correction is illustrative, not flight-safe.
# NB, NS, Z, PS, PB = Negative Big, Negative Small, Zero, Positive Small, Positive Big.
TERMS = ['NB','NS','Z','PS','PB']
ERROR_MF = [(-30,-30,-10),(-30,-15,0),(-8,0,8),(0,15,30),(10,30,30)]
RATE_MF = [(-100,-100,-30),(-100,-50,0),(-20,0,20),(0,50,100),(30,100,100)]
OUT_MF = [(-100,-100,-40),(-100,-50,0),(-20,0,20),(0,50,100),(40,100,100)]
TABLE = [
    ['Z','NS','NB','NB','NB'],
    ['PS','Z','NS','NB','NB'],
    ['PB','PS','Z','NS','NB'],
    ['PB','PB','PS','Z','NS'],
    ['PB','PB','PB','PS','Z'],
]
def create_controller():
    error=ctrl.Antecedent(np.arange(-30,31,.5),'error')
    rate=ctrl.Antecedent(np.arange(-100,101,1),'rate')
    correction=ctrl.Consequent(np.arange(-100,100.1,.1),'correction')
    for i,term in enumerate(TERMS):
        error[term]=fuzz.trimf(error.universe,list(ERROR_MF[i]))
        rate[term]=fuzz.trimf(rate.universe,list(RATE_MF[i]))
        correction[term]=fuzz.trimf(correction.universe,list(OUT_MF[i]))
    rules=[ctrl.Rule(error[TERMS[i]] & rate[TERMS[j]],correction[TABLE[i][j]])
           for i in range(5) for j in range(5)]
    return ctrl.ControlSystemSimulation(ctrl.ControlSystem(rules))

def correct(angle_error,angular_rate):
    if not (-30 <= angle_error <= 30 and -100 <= angular_rate <= 100):
        raise ValueError('Angle error or rate outside input range')
    sim=create_controller()
    sim.input['error']=angle_error
    sim.input['rate']=angular_rate
    sim.compute()
    return round(sim.output['correction'],2)

roll_error=-12; roll_rate=5
pitch_error=7; pitch_rate=-2
print('Roll error:',roll_error,'Roll rate:',roll_rate)
print('Roll correction (%):',correct(roll_error,roll_rate))
print('Pitch error:',pitch_error,'Pitch rate:',pitch_rate)
print('Pitch correction (%):',correct(pitch_error,pitch_rate))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed; edit the demo values above.
# OUTPUT: Requires scikit-fuzzy installed. Not runtime-tested here.
