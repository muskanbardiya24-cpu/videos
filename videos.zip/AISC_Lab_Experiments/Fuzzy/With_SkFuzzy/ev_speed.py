# Electric Vehicle Fuzzy Motor Power - scikit-fuzzy
# Ubuntu: python3 ev_speed.py
# BEFORE offline exam install (while online):
# sudo apt install python3-venv
# python3 -m venv ~/aisc-env
# source ~/aisc-env/bin/activate
# python3 -m pip install numpy scikit-fuzzy
# After installation, program works without internet.

import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

# ELECTRIC VEHICLE MOTOR POWER - FUZZY CONTROLLER
# Inputs: speed error = desired speed - current speed; acceleration.
# Original 9 rules: negative error -> low; zero error -> low/medium;
# positive error -> medium/high depending on acceleration.

RULES = [
    [0,0,0],
    [1,1,0],
    [2,2,1],
]

speed = ctrl.Antecedent(np.arange(-50,51,1),'speed_error')
acc = ctrl.Antecedent(np.arange(-10,11,1),'acceleration')
power = ctrl.Consequent(np.arange(0,100.1,.1),'motor_power')
for term,pts in zip(['neg','zero','pos'],[[-50,-50,0],[-25,0,25],[0,50,50]]):
    speed[term] = fuzz.trimf(speed.universe,pts)
for term,pts in zip(['neg','zero','pos'],[[-10,-10,0],[-5,0,5],[0,10,10]]):
    acc[term] = fuzz.trimf(acc.universe,pts)
for term,pts in zip(['low','medium','high'],[[0,0,50],[25,50,75],[50,100,100]]):
    power[term] = fuzz.trimf(power.universe,pts)
labels=['neg','zero','pos']
outputs=['low','medium','high']
rules=[ctrl.Rule(speed[labels[i]] & acc[labels[j]], power[outputs[RULES[i][j]]])
       for i in range(3) for j in range(3)]
sim=ctrl.ControlSystemSimulation(ctrl.ControlSystem(rules))
speed_error = float(input('Speed error (-50 to 50) [20]: ') or 20)
accel = float(input('Acceleration (-10 to 10) [1]: ') or 1)
if not (-50 <= speed_error <= 50 and -10 <= accel <= 10):
    raise ValueError('Inputs out of range')
sim.input['speed_error']=speed_error
sim.input['acceleration']=accel
sim.compute()
print('Motor power (%):',round(sim.output['motor_power'],2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: 20 [Enter]
# INPUT: 1 [Enter]
# OUTPUT: Requires scikit-fuzzy installed. Not runtime-tested here.
