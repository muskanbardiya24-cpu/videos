# Room Temperature Controller - scikit-fuzzy
# Ubuntu: python3 room_temperature.py
# Setup BEFORE the offline lab exam (requires internet):
# python3 -m pip install numpy scikit-fuzzy
# Offline alternative: use the corresponding file in Fuzzy/Without_SkFuzzy.

import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl

# Mamdani fuzzy controller using scikit-fuzzy.
lo1,hi1 = 10,40
lo2,hi2 = 15,30
out_lo,out_hi = 0,100
a = ctrl.Antecedent(np.linspace(lo1,hi1,101),'input_a')
b = ctrl.Antecedent(np.linspace(lo2,hi2,101),'input_b')
c = ctrl.Consequent(np.linspace(out_lo,out_hi,201),'output')
for var,lo,hi in [(a,lo1,hi1),(b,lo2,hi2),(c,out_lo,out_hi)]:
    mid = (lo+hi)/2
    var['low'] = fuzz.trimf(var.universe,[lo,lo,mid])
    var['mid'] = fuzz.trimf(var.universe,[lo,mid,hi])
    var['high'] = fuzz.trimf(var.universe,[mid,hi,hi])

def output_level(i,j):
    return max(0,min(2,1+j-i))

labels = ['low','mid','high']
rules = [ctrl.Rule(a[labels[i]] & b[labels[j]],
                   c[labels[output_level(i,j)]])
         for i in range(3) for j in range(3)]
system = ctrl.ControlSystem(rules)
sim = ctrl.ControlSystemSimulation(system)
x = float(input('current temperature (C): ') or '18')
y = float(input('target temperature (C): ') or '24')
if not (lo1 <= x <= hi1 and lo2 <= y <= hi2):
    raise ValueError('Inputs must be inside the indicated ranges.')
sim.input['input_a'] = x
sim.input['input_b'] = y
sim.compute()
print('heater power (%):',round(sim.output['output'],2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: 18
# INPUT: 24
# OUTPUT: Not tested here (scikit-fuzzy is not installed).
# OUTPUT: Approximate result using pure-Python version:
# OUTPUT: current temperature (C): target temperature (C): heater power (%): 55.28
