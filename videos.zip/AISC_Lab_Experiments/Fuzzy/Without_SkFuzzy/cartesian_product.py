# Fuzzy Cartesian Product
# Ubuntu: python3 cartesian_product.py
# Dependencies: Python 3 standard library only (no internet needed).

A = [0.3, 0.7, 1.0]
B = [0.4, 0.9]

R = []

for i in range(len(A)):
    row = []

    for j in range(len(B)):
        row.append(min(A[i], B[j]))

    R.append(row)

print("Set A =", A)
print("Set B =", B)

print("Cartesian Product Matrix:")
for row in R:
    print(row)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Set A = [0.3, 0.7, 1.0]
# OUTPUT: Set B = [0.4, 0.9]
# OUTPUT: Cartesian Product Matrix:
# OUTPUT: [0.3, 0.3]
# OUTPUT: [0.4, 0.7]
# OUTPUT: [0.4, 0.9]
