# Drone Roll and Pitch Stabilization - Offline Pure Python
# Ubuntu: python3 drone_stabilization.py
# No installation or internet necessary.

# Two independent controllers: roll and pitch, as in supplied lab source.
# Signed correction is illustrative, not flight-safe.
# NB, NS, Z, PS, PB = Negative Big, Negative Small, Zero, Positive Small, Positive Big.
TERMS = ['NB','NS','Z','PS','PB']
ERROR_MF = [(-30,-30,-10),(-30,-15,0),(-8,0,8),(0,15,30),(10,30,30)]
RATE_MF = [(-100,-100,-30),(-100,-50,0),(-20,0,20),(0,50,100),(30,100,100)]
OUT_MF = [(-100,-100,-40),(-100,-50,0),(-20,0,20),(0,50,100),(40,100,100)]
TABLE = [
    ['Z','NS','NB','NB','NB'],
    ['PS','Z','NS','NB','NB'],
    ['PB','PS','Z','NS','NB'],
    ['PB','PB','PS','Z','NS'],
    ['PB','PB','PB','PS','Z'],
]
def membership(x,a,b,c):
    if a == b and x <= b: return 1.0
    if b == c and x >= b: return 1.0
    if x <= a or x >= c: return 0.0
    if x < b: return (x-a)/(b-a)
    return (c-x)/(c-b)

def correct(angle_error,angular_rate):
    if not (-30 <= angle_error <= 30 and -100 <= angular_rate <= 100):
        raise ValueError('Angle error or rate outside input range')
    strengths = {label:0.0 for label in TERMS}
    for i in range(5):
        for j in range(5):
            fire = min(membership(angle_error,*ERROR_MF[i]),
                       membership(angular_rate,*RATE_MF[j]))
            out_label = TABLE[i][j]
            strengths[out_label] = max(strengths[out_label],fire)
    num=den=0.0
    for k in range(-1000,1001):
        power = k/10
        grade=max(min(strengths[TERMS[i]],membership(power,*OUT_MF[i]))
                  for i in range(5))
        num += power*grade
        den += grade
    if den==0: raise ValueError('No fuzzy rules activated')
    return round(num/den,2)

roll_error = -12; roll_rate=5
pitch_error = 7; pitch_rate=-2
print('Roll error:',roll_error,'Roll rate:',roll_rate)
print('Roll correction (%):',correct(roll_error,roll_rate))
print('Pitch error:',pitch_error,'Pitch rate:',pitch_rate)
print('Pitch correction (%):',correct(pitch_error,pitch_rate))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No interactive input; uses demo roll and pitch values.
# OUTPUT: Roll error: -12 Roll rate: 5
# OUTPUT: Roll correction (%): -50.26
# OUTPUT: Pitch error: 7 Pitch rate: -2
# OUTPUT: Pitch correction (%): 45.96
