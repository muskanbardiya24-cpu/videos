# Electric Vehicle Fuzzy Motor Power - No External Libraries
# Ubuntu: python3 ev_speed.py
# Dependencies: Python standard library only. No internet required.

# ELECTRIC VEHICLE MOTOR POWER - FUZZY CONTROLLER
# Inputs: speed error = desired speed - current speed; acceleration.
# Original 9 rules: negative error -> low; zero error -> low/medium;
# positive error -> medium/high depending on acceleration.

RULES = [
    [0,0,0],
    [1,1,0],
    [2,2,1],
]

def mf(x,a,b,c):
    if a == b and x <= b: return 1.0
    if b == c and x >= b: return 1.0
    if x <= a or x >= c: return 0.0
    if x < b: return (x-a)/(b-a)
    return (c-x)/(c-b)

ERROR = [(-50,-50,0),(-25,0,25),(0,50,50)]
ACCEL = [(-10,-10,0),(-5,0,5),(0,10,10)]
POWER = [(0,0,50),(25,50,75),(50,100,100)]

speed_error = float(input('Speed error (-50 to 50) [20]: ') or 20)
accel = float(input('Acceleration (-10 to 10) [1]: ') or 1)
if not (-50 <= speed_error <= 50 and -10 <= accel <= 10):
    raise ValueError('Inputs out of range')

strength = [0.,0.,0.]
for i in range(3):
    for j in range(3):
        activation = min(mf(speed_error,*ERROR[i]), mf(accel,*ACCEL[j]))
        output_index = RULES[i][j]
        strength[output_index] = max(strength[output_index],activation)

num = den = 0.0
for k in range(1001):
    power = k/10
    grade = max(min(strength[i],mf(power,*POWER[i])) for i in range(3))
    num += power*grade
    den += grade
if den == 0: raise ValueError('No fuzzy rules activated.')
print('Motor power (%):',round(num/den,2))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: Press Enter twice to select 20 and 1.
# OUTPUT: Speed error (-50 to 50) [20]: Acceleration (-10 to 10) [1]: Motor power (%): 63.66
