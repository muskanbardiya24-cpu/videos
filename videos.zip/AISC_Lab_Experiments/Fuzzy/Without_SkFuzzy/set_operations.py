# Fuzzy Union Intersection Complement
# Ubuntu: python3 set_operations.py
# Dependencies: Python 3 standard library only (no internet needed).

A = [0, 0.75, 1, 0.5, 0]
B = [0, 0.25, 0.75, 1, 0.5]

union = []
intersection = []

for i in range(len(A)):
    union.append(max(A[i], B[i]))
    intersection.append(min(A[i], B[i]))

complement_A = [1-x for x in A]
complement_B = [1-x for x in B]
complement_union = [1-x for x in union]
complement_intersection = [1-x for x in intersection]

print("A =", A)
print("B =", B)
print("A union B =", union)
print("A intersection B =", intersection)
print("Complement of A =", complement_A)
print("Complement of B =", complement_B)
print("Complement of union =", complement_union)
print("Complement of intersection =", complement_intersection)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: A = [0, 0.75, 1, 0.5, 0]
# OUTPUT: B = [0, 0.25, 0.75, 1, 0.5]
# OUTPUT: A union B = [0, 0.75, 1, 1, 0.5]
# OUTPUT: A intersection B = [0, 0.25, 0.75, 0.5, 0]
# OUTPUT: Complement of A = [1, 0.25, 0, 0.5, 1]
# OUTPUT: Complement of B = [1, 0.75, 0.25, 0, 0.5]
# OUTPUT: Complement of union = [1, 0.25, 0, 0, 0.5]
# OUTPUT: Complement of intersection = [1, 0.75, 0.25, 0.5, 1]
