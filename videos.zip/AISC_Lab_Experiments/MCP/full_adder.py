# Full Adder using MCP Neuron
# Ubuntu: python3 full_adder.py
# Dependencies: Python 3 standard library only (no internet needed).

# Full Adder using McCulloch-Pitts Neuron
def neuron(inputs, weights, threshold):
    weighted_sum = 0
    for i in range(len(inputs)):
        weighted_sum += inputs[i] * weights[i]
    if weighted_sum >= threshold:
        return 1
    else:
        return 0

# Logic Gates
def AND(a, b):
    return neuron([a, b], [1, 1], 2)

def OR(a, b):
    return neuron([a, b], [1, 1], 1)

def NAND(a, b):
    return neuron([a, b], [-1, -1], -1)

# XOR using NAND, AND and OR
def XOR(a, b):
    n = NAND(a, b)
    p = AND(a, n)
    q = AND(b, n)
    return OR(p, q)

# Full Adder Implementation
print("FULL ADDER USING McCULLOCH-PITTS NEURON")
print("---------------------------------------")
print("A  B  Cin | SUM  CARRY")
print("---------------------------------------")


for A in [0, 1]:
    for B in [0, 1]:
        for Cin in [0, 1]:
            # Sum = A XOR B XOR Cin
            x = XOR(A, B)
            SUM = XOR(x, Cin)
            # Carry = AB + Cin(A XOR B)
            CARRY = OR(AND(A, B),AND(x, Cin))
            print(A, " ", B, " ", Cin," |  ", SUM,"     ", CARRY)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: FULL ADDER USING McCULLOCH-PITTS NEURON
# OUTPUT: ---------------------------------------
# OUTPUT: A  B  Cin | SUM  CARRY
# OUTPUT: ---------------------------------------
# OUTPUT: 0   0   0  |   0       0
# OUTPUT: 0   0   1  |   1       0
# OUTPUT: 0   1   0  |   1       0
# OUTPUT: 0   1   1  |   0       1
# OUTPUT: 1   0   0  |   1       0
# OUTPUT: 1   0   1  |   0       1
# OUTPUT: 1   1   0  |   0       1
# OUTPUT: 1   1   1  |   1       1
