# McCulloch Pitts Neuron Logic Gates
# Ubuntu: python3 logic_gates.py
# Dependencies: Python 3 standard library only (no internet needed).

def neuron(inputs, weights, threshold):
    return int(sum(x*w for x,w in zip(inputs,weights)) >= threshold)

def AND(a,b): return neuron([a,b],[1,1],2)
def OR(a,b): return neuron([a,b],[1,1],1)
def NOT(a): return neuron([a],[-1],0)
def NAND(a,b): return neuron([a,b],[-1,-1],-1)

print('A B | AND OR NAND')
for a in (0,1):
    for b in (0,1):
        print(a,b,'|',AND(a,b),OR(a,b),NAND(a,b))
print('NOT(0)=',NOT(0),'NOT(1)=',NOT(1))

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: A B | AND OR NAND
# OUTPUT: 0 0 | 0 0 1
# OUTPUT: 0 1 | 0 1 1
# OUTPUT: 1 0 | 0 1 1
# OUTPUT: 1 1 | 1 1 0
# OUTPUT: NOT(0)= 1 NOT(1)= 0
