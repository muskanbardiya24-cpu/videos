# Single Layer Perceptron AND
# Ubuntu: python3 and_gate.py
# Dependencies: Python 3 standard library only (no internet needed).

# Single Layer Perceptron for AND Gate
# AND gate dataset
X = [[0,0],
     [0,1],
     [1,0],
     [1,1]]
T = [0,0,0,1]

# Initial parameters
w1 = 0.0
w2 = 0.0
bias = 0.0
learning_rate = 0.1

# Step activation function
def activation(yin):
    if yin > 0:
        return 1
    else:
        return 0

print("Epoch\tw1\tw2\tBias")

# Training
for epoch in range(1, 11):
    total_error = 0
    for i in range(len(X)):
        x1 = X[i][0]
        x2 = X[i][1]

        # Calculate net input
        yin = x1*w1 + x2*w2 + bias
        # Prediction
        y = activation(yin)
        # Error
        error = T[i] - y
        # Weight update
        w1 = w1 + learning_rate * error * x1
        w2 = w2 + learning_rate * error * x2
        # Bias update
        bias = bias + learning_rate * error

        total_error += abs(error)

    print(epoch,
          round(w1,2),
          round(w2,2),
          round(bias,2))

    # Stop if all outputs are correct
    correct = True
    for i in range(len(X)):
        x1 = X[i][0]
        x2 = X[i][1]

        y = activation(x1*w1 + x2*w2 + bias)

        if y != T[i]:
            correct = False
            break

    if correct:
        print("Training completed")
        break

# Testing
print("\nFinal Weights:")
print("w1 =", round(w1,2))
print("w2 =", round(w2,2))
print("Bias =", round(bias,2))
print("\nFinal Output:")
for i in range(len(X)):
    x1 = X[i][0]
    x2 = X[i][1]
    yin = x1*w1 + x2*w2 + bias
    output = activation(yin)
    print(X[i], "Target:", T[i], "Output:", output)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Epoch	w1	w2	Bias
# OUTPUT: 1 0.1 0.1 0.1
# OUTPUT: 2 0.2 0.1 0.0
# OUTPUT: 3 0.2 0.1 -0.1
# OUTPUT: 4 0.2 0.2 -0.1
# OUTPUT: 5 0.2 0.1 -0.2
# OUTPUT: Training completed
# OUTPUT: 
# OUTPUT: Final Weights:
# OUTPUT: w1 = 0.2
# OUTPUT: w2 = 0.1
# OUTPUT: Bias = -0.2
# OUTPUT: 
# OUTPUT: Final Output:
# OUTPUT: [0, 0] Target: 0 Output: 0
# OUTPUT: [0, 1] Target: 0 Output: 0
# OUTPUT: ... extra lines omitted from sample
