# Perceptron Apple vs Orange
# Ubuntu: python3 apple_orange.py
# Dependencies: Python 3 standard library only (no internet needed).

# Fruit classification demo: 1=Apple, 0=Orange.
# Features: shape, texture, weight (synthetic binary values).
X = [[1,1,1],[1,0,1],[0,1,1],[0,0,1],
     [1,1,0],[1,0,0],[0,1,0],[0,0,0]]
y = [1,1,1,1,0,0,0,0]
w, bias, lr = [0.0]*3, 0.0, 0.1
for epoch in range(20):
    for row, target in zip(X,y):
        prediction = int(sum(a*b for a,b in zip(w,row))+bias >= 0)
        error = target-prediction
        w = [wi+lr*error*xi for wi,xi in zip(w,row)]
        bias += lr*error
print('Learned weights:', [round(a,2) for a in w])
for row in [[1,0,1],[0,1,0]]:
    result = int(sum(a*b for a,b in zip(w,row))+bias >= 0)
    print(row,'->','Apple' if result else 'Orange')

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Learned weights: [-0.1, -0.1, 0.3]
# OUTPUT: [1, 0, 1] -> Apple
# OUTPUT: [0, 1, 0] -> Orange
