# XOR Using Two Layer Perceptron
# Ubuntu: python3 xor_mlp.py
# Dependencies: Python 3 standard library only (no internet needed).

# XOR cannot be learned by a single-layer perceptron.
# This example uses a two-neuron hidden layer with fixed weights.
def step(x): return int(x >= 0)
for x1,x2 in [(0,0),(0,1),(1,0),(1,1)]:
    h_or = step(x1+x2-0.5)
    h_and = step(x1+x2-1.5)
    out = step(h_or-2*h_and-0.5)
    print(x1,x2,'XOR =',out)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: 0 0 XOR = 0
# OUTPUT: 0 1 XOR = 1
# OUTPUT: 1 0 XOR = 1
# OUTPUT: 1 1 XOR = 0
