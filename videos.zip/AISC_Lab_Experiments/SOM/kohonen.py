# Kohonen SOM (Winner Takes Most)
# Ubuntu: python3 kohonen.py
# Dependencies: Python 3 standard library only (no internet needed).

# Self Organizing Map: two prototype neurons, winner update.
import math
X = [(0.2,0.3),(0.25,0.35),(0.8,0.9),(0.75,0.85)]
weights = [[0.1,0.2],[0.9,0.8]]
rate = 0.5
for epoch in range(10):
    for x in X:
        winner = min(range(len(weights)), key=lambda i:
            math.dist(weights[i],x))
        weights[winner] = [w + rate*(v-w) for w,v in zip(weights[winner],x)]
print('Final neuron weights:')
for i,w in enumerate(weights):
    print('Neuron',i+1, [round(v,3) for v in w])
for x in X:
    winner = min(range(len(weights)),key=lambda i:math.dist(weights[i],x))
    print(x,'-> neuron',winner+1)

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: Final neuron weights:
# OUTPUT: Neuron 1 [0.233, 0.333]
# OUTPUT: Neuron 2 [0.767, 0.867]
# OUTPUT: (0.2, 0.3) -> neuron 1
# OUTPUT: (0.25, 0.35) -> neuron 1
# OUTPUT: (0.8, 0.9) -> neuron 2
# OUTPUT: (0.75, 0.85) -> neuron 2
