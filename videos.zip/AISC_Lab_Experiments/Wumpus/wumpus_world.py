# Wumpus World Fixed Safe Route
# Ubuntu: python3 wumpus_world.py
# Dependencies: Python 3 standard library only (no internet needed).

# Fixed 4x4 demonstration. Rows and columns are numbered 1..4.
size = 4
wumpus, gold = (1,3), (2,3)
pits = {(3,1),(3,3),(4,4)}
position = (1,1)
path_to_gold = [(2,1),(2,2),(2,3)]

def neighbors(pos):
    r,c = pos
    return {(a,b) for a,b in [(r+1,c),(r-1,c),(r,c+1),(r,c-1)]
            if 1 <= a <= size and 1 <= b <= size}

def report(pos):
    adj = neighbors(pos)
    print('At',pos,'| Breeze:',bool(adj & pits),
          '| Stench:',wumpus in adj,'| Glitter:',pos == gold)

report(position)
for next_pos in path_to_gold + path_to_gold[-2::-1] + [(1,1)]:
    if next_pos in pits or next_pos == wumpus:
        print('Agent lost at',next_pos)
        break
    position = next_pos
    report(position)
else:
    print('SUCCESS: gold collected and agent returned to start')

# ---------------- SAMPLE INPUT AND OUTPUT ----------------
# INPUT: No input needed.
# OUTPUT: At (1, 1) | Breeze: False | Stench: False | Glitter: False
# OUTPUT: At (2, 1) | Breeze: True | Stench: False | Glitter: False
# OUTPUT: At (2, 2) | Breeze: False | Stench: False | Glitter: False
# OUTPUT: At (2, 3) | Breeze: True | Stench: True | Glitter: True
# OUTPUT: At (2, 2) | Breeze: False | Stench: False | Glitter: False
# OUTPUT: At (2, 1) | Breeze: True | Stench: False | Glitter: False
# OUTPUT: At (1, 1) | Breeze: False | Stench: False | Glitter: False
# OUTPUT: SUCCESS: gold collected and agent returned to start
